import { ColumnOptionsStep, ColumnPrimaryStep, ColumnTypeStep } from './column-builder-step';
import { BaseAction } from '../../actions';
import { TableColumnOptions } from '../../types';
export declare class ColumnBuilder implements ColumnTypeStep, ColumnPrimaryStep, ColumnOptionsStep {
    private options;
    actions: BaseAction[];
    static new(name: string): ColumnBuilder;
    uuid(): ColumnOptionsStep & ColumnPrimaryStep;
    integer(): ColumnOptionsStep & ColumnPrimaryStep;
    boolean(): ColumnOptionsStep;
    string(length?: number): ColumnOptionsStep;
    text(): ColumnOptionsStep;
    timestamp(): ColumnOptionsStep;
    float(precision?: number, scale?: number): ColumnOptionsStep;
    double(precision?: number, scale?: number): ColumnOptionsStep;
    decimal(precision?: number, scale?: number): ColumnOptionsStep;
    primary(): ColumnPrimaryStep;
    nullable(): ColumnOptionsStep;
    unique(): ColumnOptionsStep;
    default(value: any): ColumnOptionsStep & ColumnPrimaryStep;
    autoIncrement(): ColumnPrimaryStep;
    index(): ColumnOptionsStep;
    foreign(referenceTable: string, referenceColumn?: string): ColumnOptionsStep;
    build(): TableColumnOptions;
}
