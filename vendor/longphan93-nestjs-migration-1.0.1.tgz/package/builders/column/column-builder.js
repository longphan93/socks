"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColumnBuilder = void 0;
const actions_1 = require("../../actions");
const enums_1 = require("../../enums");
class ColumnBuilder {
    options;
    actions = [];
    static new(name) {
        const builder = new ColumnBuilder();
        builder.options = { name, isNullable: false };
        return builder;
    }
    uuid() {
        this.options.type = enums_1.ColumnTypeEnum.UUID;
        return this;
    }
    integer() {
        this.options.type = enums_1.ColumnTypeEnum.INTEGER;
        return this;
    }
    boolean() {
        this.options.type = enums_1.ColumnTypeEnum.BOOLEAN;
        return this;
    }
    string(length = 255) {
        this.options.type = enums_1.ColumnTypeEnum.STRING;
        this.options.length = length;
        return this;
    }
    text() {
        this.options.type = enums_1.ColumnTypeEnum.TEXT;
        return this;
    }
    timestamp() {
        this.options.type = enums_1.ColumnTypeEnum.TIMESTAMP;
        return this;
    }
    float(precision, scale) {
        this.options.type = enums_1.ColumnTypeEnum.FLOAT;
        this.options.precision = precision;
        this.options.scale = scale;
        return this;
    }
    double(precision, scale) {
        this.options.type = enums_1.ColumnTypeEnum.DOUBLE;
        this.options.precision = precision;
        this.options.scale = scale;
        return this;
    }
    decimal(precision, scale) {
        this.options.type = enums_1.ColumnTypeEnum.DECIMAL;
        this.options.precision = precision;
        this.options.scale = scale;
        return this;
    }
    primary() {
        this.options.isPrimary = true;
        return this;
    }
    nullable() {
        this.options.isNullable = true;
        return this;
    }
    unique() {
        this.options.isUnique = true;
        return this;
    }
    default(value) {
        this.options.default = value;
        return this;
    }
    autoIncrement() {
        this.options.autoIncrement = true;
        return this;
    }
    index() {
        this.actions.push(new actions_1.CreateIndexAction([this.options.name]));
        return this;
    }
    foreign(referenceTable, referenceColumn) {
        this.actions.push(new actions_1.CreateForeignKeyAction([this.options.name], referenceTable, referenceColumn ? [referenceColumn] : ['id']));
        return this;
    }
    build() {
        if (!this.options.type) {
            throw new Error(`Column type is not defined for column: ${this.options.name}`);
        }
        return this.options;
    }
}
exports.ColumnBuilder = ColumnBuilder;
//# sourceMappingURL=column-builder.js.map