import { BaseExecutor } from '../../executors';
import { ColumnTypeStep } from '../column';
import { TableBuilder } from './table-builder';
export declare class CreateTableBuilder extends TableBuilder {
    private name;
    private columns;
    private actions;
    constructor(name: string);
    execute(executor: BaseExecutor): Promise<void>;
    column(name: string): ColumnTypeStep;
    primaryColumns(columns: string[]): void;
}
