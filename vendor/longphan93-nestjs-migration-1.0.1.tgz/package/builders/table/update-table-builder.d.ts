import { BaseExecutor } from '../../executors';
import { ColumnTypeStep } from '../column';
import { TableBuilder } from './table-builder';
export declare class UpdateTableBuilder extends TableBuilder {
    private name;
    private columns;
    private actions;
    constructor(name: string);
    execute(executor: BaseExecutor): Promise<void>;
    addColumn(name: string): ColumnTypeStep;
    dropColumn(name: string): void;
    createIndex(columns: string[], constraintName?: string): void;
}
