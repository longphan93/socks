import { BaseExecutor } from '../../executors';
export declare abstract class TableBuilder {
    abstract execute(executor: BaseExecutor): Promise<void>;
}
