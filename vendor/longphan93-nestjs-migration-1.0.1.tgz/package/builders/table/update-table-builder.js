"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateTableBuilder = void 0;
const actions_1 = require("../../actions");
const column_1 = require("../column");
const table_builder_1 = require("./table-builder");
const drop_column_action_1 = require("../../actions/drop-column.action");
class UpdateTableBuilder extends table_builder_1.TableBuilder {
    name;
    columns = [];
    actions = [];
    constructor(name) {
        super();
        this.name = name;
    }
    async execute(executor) {
        for (const column of this.columns) {
            await executor.createColumn(this.name, column.build());
        }
        for (const action of this.actions) {
            await action.execute(executor, this.name);
        }
    }
    addColumn(name) {
        const builder = column_1.ColumnBuilder.new(name);
        this.columns.push(builder);
        return builder;
    }
    dropColumn(name) {
        this.actions.push(new drop_column_action_1.DropColumnAction(name));
    }
    createIndex(columns, constraintName) {
        this.actions.push(new actions_1.CreateIndexAction(columns, constraintName));
    }
}
exports.UpdateTableBuilder = UpdateTableBuilder;
//# sourceMappingURL=update-table-builder.js.map