"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTableBuilder = void 0;
const actions_1 = require("../../actions");
const column_1 = require("../column");
const table_builder_1 = require("./table-builder");
class CreateTableBuilder extends table_builder_1.TableBuilder {
    name;
    columns = [];
    actions = [];
    constructor(name) {
        super();
        this.name = name;
    }
    async execute(executor) {
        const columns = this.columns.map((column) => column.build());
        const actions = [...this.columns.flatMap((column) => column.actions), ...this.actions];
        await executor.createTable(this.name, columns);
        for (const action of actions) {
            await action.execute(executor, this.name);
        }
    }
    column(name) {
        const builder = column_1.ColumnBuilder.new(name);
        this.columns.push(builder);
        return builder;
    }
    primaryColumns(columns) {
        this.actions.push(new actions_1.CreatePrimaryKeyAction(columns));
    }
}
exports.CreateTableBuilder = CreateTableBuilder;
//# sourceMappingURL=create-table-builder.js.map