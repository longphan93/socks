"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColumnTypeEnum = void 0;
var ColumnTypeEnum;
(function (ColumnTypeEnum) {
    ColumnTypeEnum["UUID"] = "uuid";
    ColumnTypeEnum["STRING"] = "string";
    ColumnTypeEnum["TEXT"] = "text";
    ColumnTypeEnum["INTEGER"] = "integer";
    ColumnTypeEnum["BOOLEAN"] = "boolean";
    ColumnTypeEnum["TIMESTAMP"] = "timestamp";
    ColumnTypeEnum["FLOAT"] = "float";
    ColumnTypeEnum["DOUBLE"] = "double";
    ColumnTypeEnum["DECIMAL"] = "decimal";
})(ColumnTypeEnum || (exports.ColumnTypeEnum = ColumnTypeEnum = {}));
//# sourceMappingURL=column-type.enum.js.map