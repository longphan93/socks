"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DropColumnAction = void 0;
const base_action_1 = require("./base.action");
class DropColumnAction extends base_action_1.BaseAction {
    column;
    constructor(column) {
        super();
        this.column = column;
    }
    execute(executor, table) {
        return executor.dropColumn(table, this.column);
    }
}
exports.DropColumnAction = DropColumnAction;
//# sourceMappingURL=drop-column.action.js.map