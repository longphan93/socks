import { BaseExecutor } from '../executors/base.executor';
export declare abstract class BaseAction {
    abstract execute(executor: BaseExecutor, table: string): Promise<void>;
}
