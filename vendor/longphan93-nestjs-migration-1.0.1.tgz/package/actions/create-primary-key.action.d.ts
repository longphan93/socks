import { BaseAction } from './base.action';
import { BaseExecutor } from '../executors';
export declare class CreatePrimaryKeyAction extends BaseAction {
    columns: string[];
    constraintName?: string | undefined;
    constructor(columns: string[], constraintName?: string | undefined);
    execute(executor: BaseExecutor, table: string): Promise<void>;
}
