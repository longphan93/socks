"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateIndexAction = void 0;
const base_action_1 = require("./base.action");
class CreateIndexAction extends base_action_1.BaseAction {
    columns;
    constraintName;
    constructor(columns, constraintName) {
        super();
        this.columns = columns;
        this.constraintName = constraintName;
    }
    async execute(executor, table) {
        await executor.createIndex(table, this);
    }
}
exports.CreateIndexAction = CreateIndexAction;
//# sourceMappingURL=create-index.action.js.map