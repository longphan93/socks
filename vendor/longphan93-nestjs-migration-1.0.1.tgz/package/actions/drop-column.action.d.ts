import { BaseExecutor } from '../executors';
import { BaseAction } from './base.action';
export declare class DropColumnAction extends BaseAction {
    column: string;
    constructor(column: string);
    execute(executor: BaseExecutor, table: string): Promise<void>;
}
