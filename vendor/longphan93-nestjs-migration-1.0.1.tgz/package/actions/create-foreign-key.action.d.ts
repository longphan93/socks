import { BaseAction } from './base.action';
import { BaseExecutor } from '../executors';
export declare class CreateForeignKeyAction extends BaseAction {
    columns: string[];
    referenceTable: string;
    referenceColumns: string[];
    constraintName?: string | undefined;
    onDelete?: "CASCADE" | "SET NULL" | "RESTRICT" | "NO ACTION" | undefined;
    onUpdate?: "CASCADE" | "SET NULL" | "RESTRICT" | "NO ACTION" | undefined;
    constructor(columns: string[], referenceTable: string, referenceColumns: string[], constraintName?: string | undefined, onDelete?: "CASCADE" | "SET NULL" | "RESTRICT" | "NO ACTION" | undefined, onUpdate?: "CASCADE" | "SET NULL" | "RESTRICT" | "NO ACTION" | undefined);
    execute(executor: BaseExecutor, table: string): Promise<void>;
}
