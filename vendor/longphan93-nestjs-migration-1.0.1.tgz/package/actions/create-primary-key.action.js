"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreatePrimaryKeyAction = void 0;
const base_action_1 = require("./base.action");
class CreatePrimaryKeyAction extends base_action_1.BaseAction {
    columns;
    constraintName;
    constructor(columns, constraintName) {
        super();
        this.columns = columns;
        this.constraintName = constraintName;
    }
    async execute(executor, table) {
        await executor.createPrimary(table, this);
    }
}
exports.CreatePrimaryKeyAction = CreatePrimaryKeyAction;
//# sourceMappingURL=create-primary-key.action.js.map