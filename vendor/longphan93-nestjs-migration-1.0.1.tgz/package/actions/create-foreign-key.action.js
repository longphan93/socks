"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateForeignKeyAction = void 0;
const base_action_1 = require("./base.action");
class CreateForeignKeyAction extends base_action_1.BaseAction {
    columns;
    referenceTable;
    referenceColumns;
    constraintName;
    onDelete;
    onUpdate;
    constructor(columns, referenceTable, referenceColumns, constraintName, onDelete, onUpdate) {
        super();
        this.columns = columns;
        this.referenceTable = referenceTable;
        this.referenceColumns = referenceColumns;
        this.constraintName = constraintName;
        this.onDelete = onDelete;
        this.onUpdate = onUpdate;
    }
    async execute(executor, table) {
        await executor.createForeignKey(table, this);
    }
}
exports.CreateForeignKeyAction = CreateForeignKeyAction;
//# sourceMappingURL=create-foreign-key.action.js.map