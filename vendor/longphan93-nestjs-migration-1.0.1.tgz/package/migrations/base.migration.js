"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseMigration = void 0;
const builders_1 = require("../builders");
class BaseMigration {
    executor;
    initialize(executor) {
        this.executor = executor;
    }
    async createTable(name, callback) {
        const builder = new builders_1.CreateTableBuilder(name);
        callback(builder);
        await builder.execute(this.executor);
    }
    async updateTable(name, callback) {
        const builder = new builders_1.UpdateTableBuilder(name);
        callback(builder);
        await builder.execute(this.executor);
    }
    async dropTable(name) {
        await this.executor.dropTable(name);
    }
    async runSQL(query) {
        await this.executor.runSQL(query);
    }
}
exports.BaseMigration = BaseMigration;
//# sourceMappingURL=base.migration.js.map