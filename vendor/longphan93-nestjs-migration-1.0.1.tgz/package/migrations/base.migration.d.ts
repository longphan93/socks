import { BaseExecutor } from '../executors';
import { CreateTableBuilder, UpdateTableBuilder } from '../builders';
export declare abstract class BaseMigration {
    protected executor: BaseExecutor;
    abstract execute(): Promise<void>;
    abstract rollback(): Promise<void>;
    protected initialize(executor: BaseExecutor): void;
    createTable(name: string, callback: (builder: CreateTableBuilder) => void): Promise<void>;
    updateTable(name: string, callback: (builder: UpdateTableBuilder) => void): Promise<void>;
    dropTable(name: string): Promise<void>;
    runSQL(query: string): Promise<void>;
}
