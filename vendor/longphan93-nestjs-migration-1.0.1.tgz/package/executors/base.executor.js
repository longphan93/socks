"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseExecutor = void 0;
const drivers_1 = require("../drivers");
class BaseExecutor {
    driver;
    constructor(driver) {
        this.driver = (0, drivers_1.makeDbDriver)(driver);
    }
}
exports.BaseExecutor = BaseExecutor;
//# sourceMappingURL=base.executor.js.map