import { CreateIndexAction, CreateForeignKeyAction, CreatePrimaryKeyAction } from '../../actions';
import { BaseExecutor } from '../../executors/base.executor';
import { QueryRunner } from 'typeorm';
import { TableColumnOptions } from '../../types';
export declare class TypeOrmExecutor extends BaseExecutor {
    private queryRunner;
    constructor(queryRunner: QueryRunner, driver: string);
    createTable(name: string, columns: TableColumnOptions[]): Promise<void>;
    createColumn(table: string, column: TableColumnOptions): Promise<void>;
    createIndex(table: string, action: CreateIndexAction): Promise<void>;
    createForeignKey(table: string, action: CreateForeignKeyAction): Promise<void>;
    createPrimary(table: string, action: CreatePrimaryKeyAction): Promise<void>;
    dropTable(name: string): Promise<void>;
    dropColumn(table: string, column: string): Promise<void>;
    runSQL(query: string): Promise<void>;
}
