import { TableColumn } from 'typeorm';
import { TableColumnOptions } from '../../types';
import { DbDriver } from '../../drivers';
export declare function createTableColumn(options: TableColumnOptions, driver: DbDriver): TableColumn;
