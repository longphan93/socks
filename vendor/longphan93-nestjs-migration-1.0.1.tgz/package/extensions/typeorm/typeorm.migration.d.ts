import { MigrationInterface, QueryRunner } from 'typeorm';
import { BaseMigration } from '../../migrations/base.migration';
export declare abstract class TypeOrmMigration extends BaseMigration implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<any>;
    down(queryRunner: QueryRunner): Promise<any>;
}
