"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeOrmExecutor = void 0;
const base_executor_1 = require("../../executors/base.executor");
const typeorm_1 = require("typeorm");
const typeorm_helper_1 = require("./typeorm.helper");
class TypeOrmExecutor extends base_executor_1.BaseExecutor {
    queryRunner;
    constructor(queryRunner, driver) {
        super(driver);
        this.queryRunner = queryRunner;
    }
    async createTable(name, columns) {
        const table = new typeorm_1.Table();
        table.name = name;
        table.columns = columns.map((column) => (0, typeorm_helper_1.createTableColumn)(column, this.driver));
        await this.queryRunner.createTable(table);
    }
    async createColumn(table, column) {
        await this.queryRunner.addColumn(table, (0, typeorm_helper_1.createTableColumn)(column, this.driver));
    }
    async createIndex(table, action) {
        await this.queryRunner.createIndex(table, new typeorm_1.TableIndex({
            columnNames: action.columns,
            name: action.constraintName,
        }));
    }
    async createForeignKey(table, action) {
        await this.queryRunner.createForeignKey(table, new typeorm_1.TableForeignKey({
            columnNames: action.columns,
            referencedTableName: action.referenceTable,
            referencedColumnNames: action.referenceColumns,
            onDelete: action.onDelete,
            onUpdate: action.onUpdate,
            name: action.constraintName,
        }));
    }
    async createPrimary(table, action) {
        await this.queryRunner.createPrimaryKey(table, action.columns, action.constraintName);
    }
    async dropTable(name) {
        await this.queryRunner.dropTable(name);
    }
    async dropColumn(table, column) {
        await this.queryRunner.dropColumn(table, column);
    }
    async runSQL(query) {
        await this.queryRunner.query(query);
    }
}
exports.TypeOrmExecutor = TypeOrmExecutor;
//# sourceMappingURL=typeorm.executor.js.map