"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTableColumn = createTableColumn;
const typeorm_1 = require("typeorm");
function createTableColumn(options, driver) {
    return new typeorm_1.TableColumn({
        ...options,
        type: driver.mapColumnType(options.type),
        length: options.length?.toString(),
        isGenerated: options.autoIncrement,
    });
}
//# sourceMappingURL=typeorm.helper.js.map