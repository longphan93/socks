"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeOrmMigration = void 0;
const typeorm_executor_1 = require("./typeorm.executor");
const base_migration_1 = require("../../migrations/base.migration");
class TypeOrmMigration extends base_migration_1.BaseMigration {
    up(queryRunner) {
        if (!this['driver']) {
            throw new Error('Database driver is not specified in the migration class.');
        }
        this.initialize(new typeorm_executor_1.TypeOrmExecutor(queryRunner, this['driver']));
        return this.execute();
    }
    down(queryRunner) {
        if (!this['driver']) {
            throw new Error('Database driver is not specified in the migration class.');
        }
        this.initialize(new typeorm_executor_1.TypeOrmExecutor(queryRunner, this['driver']));
        return this.rollback();
    }
}
exports.TypeOrmMigration = TypeOrmMigration;
//# sourceMappingURL=typeorm.migration.js.map