"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SequelizeMigration = void 0;
const migrations_1 = require("../../migrations");
const sequelize_executor_1 = require("./sequelize.executor");
class SequelizeMigration extends migrations_1.BaseMigration {
    up(queryInterface) {
        if (!this['driver']) {
            throw new Error('Database driver is not specified in the migration class.');
        }
        this.initialize(new sequelize_executor_1.SequelizeExecutor(queryInterface, this['driver']));
        return this.execute();
    }
    down(queryInterface) {
        if (!this['driver']) {
            throw new Error('Database driver is not specified in the migration class.');
        }
        this.initialize(new sequelize_executor_1.SequelizeExecutor(queryInterface, this['driver']));
        return this.rollback();
    }
}
exports.SequelizeMigration = SequelizeMigration;
//# sourceMappingURL=sequelize.migration.js.map