"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapDataTypes = mapDataTypes;
exports.createTableColumn = createTableColumn;
const sequelize_1 = require("sequelize");
const enums_1 = require("../../enums");
function mapDataTypes(options) {
    const constructorMap = {
        [enums_1.ColumnTypeEnum.UUID]: sequelize_1.DataTypes.UUID,
        [enums_1.ColumnTypeEnum.STRING]: sequelize_1.DataTypes.STRING(options.length),
        [enums_1.ColumnTypeEnum.TEXT]: sequelize_1.DataTypes.TEXT,
        [enums_1.ColumnTypeEnum.INTEGER]: sequelize_1.DataTypes.INTEGER,
        [enums_1.ColumnTypeEnum.BOOLEAN]: sequelize_1.DataTypes.BOOLEAN,
        [enums_1.ColumnTypeEnum.TIMESTAMP]: sequelize_1.DataTypes.DATE,
        [enums_1.ColumnTypeEnum.FLOAT]: sequelize_1.DataTypes.FLOAT(options.precision, options.scale),
        [enums_1.ColumnTypeEnum.DOUBLE]: sequelize_1.DataTypes.DOUBLE(options.precision, options.scale),
        [enums_1.ColumnTypeEnum.DECIMAL]: sequelize_1.DataTypes.DECIMAL(options.precision, options.scale),
    };
    if (!constructorMap[options.type]) {
        throw new Error(`Unsupported column type for Sequelize: ${options.type}`);
    }
    return constructorMap[options.type];
}
function createTableColumn(options, _) {
    return {
        type: mapDataTypes(options),
        allowNull: options.isNullable,
        unique: options.isUnique,
        primaryKey: options.isPrimary,
        defaultValue: options.default,
        autoIncrement: options.autoIncrement,
    };
}
//# sourceMappingURL=sequelize.helper.js.map