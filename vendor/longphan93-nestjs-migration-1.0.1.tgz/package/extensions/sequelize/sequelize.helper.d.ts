import { ModelAttributeColumnOptions } from 'sequelize';
import { DbDriver } from '../../drivers';
import { TableColumnOptions } from '../../types';
export declare function mapDataTypes(options: TableColumnOptions): ModelAttributeColumnOptions['type'];
export declare function createTableColumn(options: TableColumnOptions, _: DbDriver): ModelAttributeColumnOptions;
