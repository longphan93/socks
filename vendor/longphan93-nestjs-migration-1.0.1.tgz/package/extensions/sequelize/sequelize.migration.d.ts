import { QueryInterface } from 'sequelize';
import { BaseMigration } from '../../migrations';
export declare abstract class SequelizeMigration extends BaseMigration {
    up(queryInterface: QueryInterface): Promise<any>;
    down(queryInterface: QueryInterface): Promise<any>;
}
