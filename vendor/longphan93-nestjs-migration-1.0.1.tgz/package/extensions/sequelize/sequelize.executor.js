"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SequelizeExecutor = void 0;
const executors_1 = require("../../executors");
const sequelize_helper_1 = require("./sequelize.helper");
class SequelizeExecutor extends executors_1.BaseExecutor {
    queryInterface;
    constructor(queryInterface, driver) {
        super(driver);
        this.queryInterface = queryInterface;
    }
    async createTable(name, columns) {
        const attributes = columns.reduce((attributes, column) => {
            attributes[column.name] = (0, sequelize_helper_1.createTableColumn)(column, this.driver);
            return attributes;
        }, {});
        await this.queryInterface.createTable(name, attributes);
    }
    async createColumn(table, column) {
        await this.queryInterface.addColumn(table, column.name, (0, sequelize_helper_1.createTableColumn)(column, this.driver));
    }
    async createIndex(table, action) {
        await this.queryInterface.addIndex(table, {
            name: action.constraintName,
            fields: action.columns,
        });
    }
    async createForeignKey(table, action) {
        await this.queryInterface.addConstraint(table, {
            fields: action.columns,
            type: 'foreign key',
            name: action.constraintName,
            references: {
                table: action.referenceTable,
                field: action.referenceColumns[0],
            },
            onDelete: action.onDelete ?? 'CASCADE',
            onUpdate: action.onUpdate ?? 'CASCADE',
        });
    }
    async createPrimary(table, action) {
        await this.queryInterface.addConstraint(table, {
            type: 'primary key',
            fields: action.columns,
            name: action.constraintName,
        });
    }
    async dropTable(name) {
        await this.queryInterface.dropTable(name);
    }
    async dropColumn(table, column) {
        await this.queryInterface.removeColumn(table, column);
    }
    async runSQL(query) {
        await this.queryInterface.sequelize.query(query);
    }
}
exports.SequelizeExecutor = SequelizeExecutor;
//# sourceMappingURL=sequelize.executor.js.map