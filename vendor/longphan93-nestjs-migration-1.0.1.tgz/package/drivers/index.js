"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeDbDriver = makeDbDriver;
const mysql_driver_1 = require("./mysql.driver");
const postgres_driver_1 = require("./postgres.driver");
const sqlite_driver_1 = require("./sqlite.driver");
__exportStar(require("./db.driver"), exports);
function makeDbDriver(driverName) {
    switch (driverName) {
        case 'sqlite':
            return new sqlite_driver_1.SqliteDriver();
        case 'postgres':
            return new postgres_driver_1.PostgresDriver();
        case 'mysql':
            return new mysql_driver_1.MySqlDriver();
        default:
            throw new Error(`Unsupported database driver: ${driverName}`);
    }
}
//# sourceMappingURL=index.js.map