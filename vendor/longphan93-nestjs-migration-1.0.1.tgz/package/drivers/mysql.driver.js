"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MySqlDriver = void 0;
const enums_1 = require("../enums");
const db_driver_1 = require("./db.driver");
class MySqlDriver extends db_driver_1.DbDriver {
    mapColumnType(type) {
        switch (type) {
            case enums_1.ColumnTypeEnum.UUID:
                return 'VARCHAR(36)';
            case enums_1.ColumnTypeEnum.STRING:
                return 'VARCHAR';
            case enums_1.ColumnTypeEnum.TEXT:
                return 'TEXT';
            case enums_1.ColumnTypeEnum.TIMESTAMP:
                return 'TIMESTAMP';
            case enums_1.ColumnTypeEnum.INTEGER:
                return 'INT';
            case enums_1.ColumnTypeEnum.BOOLEAN:
                return 'TINYINT(1)';
            case enums_1.ColumnTypeEnum.FLOAT:
                return 'FLOAT';
            case enums_1.ColumnTypeEnum.DOUBLE:
                return 'DOUBLE';
            case enums_1.ColumnTypeEnum.DECIMAL:
                return 'DECIMAL';
            default:
                throw new Error(`Unsupported column type for MySQL: ${type}`);
        }
    }
}
exports.MySqlDriver = MySqlDriver;
//# sourceMappingURL=mysql.driver.js.map