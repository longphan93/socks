"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostgresDriver = void 0;
const enums_1 = require("../enums");
const db_driver_1 = require("./db.driver");
class PostgresDriver extends db_driver_1.DbDriver {
    mapColumnType(type) {
        switch (type) {
            case enums_1.ColumnTypeEnum.UUID:
                return 'UUID';
            case enums_1.ColumnTypeEnum.STRING:
                return `CHARACTER VARYING`;
            case enums_1.ColumnTypeEnum.TEXT:
                return 'TEXT';
            case enums_1.ColumnTypeEnum.INTEGER:
                return 'INTEGER';
            case enums_1.ColumnTypeEnum.BOOLEAN:
                return 'BOOLEAN';
            case enums_1.ColumnTypeEnum.FLOAT:
                return 'REAL';
            case enums_1.ColumnTypeEnum.DOUBLE:
                return 'DOUBLE PRECISION';
            case enums_1.ColumnTypeEnum.DECIMAL:
                return 'DECIMAL';
            case enums_1.ColumnTypeEnum.TIMESTAMP:
                return 'TIMESTAMP';
            default:
                throw new Error(`Unsupported column type for Postgres: ${type}`);
        }
    }
}
exports.PostgresDriver = PostgresDriver;
//# sourceMappingURL=postgres.driver.js.map