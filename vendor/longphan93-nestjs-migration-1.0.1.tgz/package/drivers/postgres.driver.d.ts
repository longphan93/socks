import { ColumnTypeEnum } from '../enums';
import { DbDriver } from './db.driver';
export declare class PostgresDriver extends DbDriver {
    mapColumnType(type: ColumnTypeEnum): string;
}
