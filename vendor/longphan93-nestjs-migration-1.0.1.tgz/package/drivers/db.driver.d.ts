import { ColumnTypeEnum } from '../enums/column-type.enum';
export declare abstract class DbDriver {
    abstract mapColumnType(type: ColumnTypeEnum): string;
}
