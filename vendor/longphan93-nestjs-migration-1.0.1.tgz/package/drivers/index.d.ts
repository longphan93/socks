import { DbDriver } from './db.driver';
export * from './db.driver';
export declare function makeDbDriver(driverName: string): DbDriver;
