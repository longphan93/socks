"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DbDriver = void 0;
class DbDriver {
}
exports.DbDriver = DbDriver;
//# sourceMappingURL=db.driver.js.map