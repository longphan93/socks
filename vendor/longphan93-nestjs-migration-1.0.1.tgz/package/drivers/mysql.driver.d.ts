import { ColumnTypeEnum } from '../enums';
import { DbDriver } from './db.driver';
export declare class MySqlDriver extends DbDriver {
    mapColumnType(type: ColumnTypeEnum): string;
}
