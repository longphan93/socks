"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SqliteDriver = void 0;
const enums_1 = require("../enums");
const db_driver_1 = require("./db.driver");
class SqliteDriver extends db_driver_1.DbDriver {
    mapColumnType(type) {
        switch (type) {
            case enums_1.ColumnTypeEnum.UUID:
            case enums_1.ColumnTypeEnum.STRING:
            case enums_1.ColumnTypeEnum.TEXT:
            case enums_1.ColumnTypeEnum.TIMESTAMP:
                return 'TEXT';
            case enums_1.ColumnTypeEnum.INTEGER:
                return 'INTEGER';
            case enums_1.ColumnTypeEnum.BOOLEAN:
                return 'INTEGER';
            case enums_1.ColumnTypeEnum.FLOAT:
            case enums_1.ColumnTypeEnum.DOUBLE:
            case enums_1.ColumnTypeEnum.DECIMAL:
                return 'REAL';
            default:
                throw new Error(`Unsupported column type for SQLite: ${type}`);
        }
    }
}
exports.SqliteDriver = SqliteDriver;
//# sourceMappingURL=sqlite.driver.js.map