import { ColumnTypeEnum } from '../enums';
import { DbDriver } from './db.driver';
export declare class SqliteDriver extends DbDriver {
    mapColumnType(type: ColumnTypeEnum): string;
}
